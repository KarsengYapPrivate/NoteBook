/////////////////////////////////////////////////////////////////////////////////
/* Config.js
/////////////////////////////////////////////////////////////////////////////////
- contain all the configurable settings for the game
*/
/////////////////////////////////////////////////////////////////////////////////
// initialise
// game settings
const totalSpin         = 100000000;
const betstake          = 1;
const maxNumber         = 100;
const maxAnimal         = 5;

// Simulation result output file name, include .txt
const simResultFile     = "Summary_spin" + totalSpin + ".txt";

// all game type
const gameAvailableType = {
    animal1     : 0,
    animal2     : 1,
    animal3     : 2,
    animal4     : 3,
    animal5     : 4,
    number2     : 5,
    number3     : 6,
    number4     : 7
}

// pay table
const paytable = {
    0   :   [    12,   0,  0,    0,    3 ],
    1   :   [    95,   0,  0,   12,    1 ],
    2   :   [   700,   0, 42,    3, 0.75 ],
    3   :   [  4000, 500, 22,  1.5,  0.2 ],
    4   :   [ 17000, 150,  8,  1.0,  0.2 ],
    5   :   [    50,   7,  1 ],
    6   :   [   500,  60,  1 ],
    7   :   [  5000, 600,  1 ]
}

// All Animal
const allAnimal = {
    animalOstrich       : 1,
    animalEagle         : 2,
    animalDonkey        : 3,
    animalButterfly     : 4,
    animalDog           : 5,
    animalGoat          : 6,
    animalSheep         : 7,
    animalCamel         : 8,
    animalSnake         : 9,
    animalRabbit        : 10,
    animalHorse         : 11,
    animalElephant      : 12,
    animalRooster       : 13,
    animalCat           : 14,
    animalAlligator     : 15,
    animalLion          : 16,
    animalMonkey        : 17,
    animalPig           : 18,
    animalPeacock       : 19,
    animalTurkey        : 20,
    animalBull          : 21,
    animalTiger         : 22,
    animalBear          : 23,
    animalDeer          : 24,
    animalCow           : 25,
}

// Number in each Animal
const animalNumber = {
    1   :  [ "01", "02", "03", "04" ],
    2   :  [ "05", "06", "07", "08" ],
    3   :  [ "09", "10", "11", "12" ],
    4   :  [ "13", "14", "15", "16" ],
    5   :  [ "17", "18", "19", "20" ],
    6   :  [ "21", "22", "23", "24" ],
    7   :  [ "25", "26", "27", "28" ],
    8   :  [ "29", "30", "31", "32" ],   
    9   :  [ "33", "34", "35", "36" ],
    10  :  [ "37", "38", "39", "40" ],
    11  :  [ "41", "42", "43", "44" ],
    12  :  [ "45", "46", "47", "48" ],
    13  :  [ "49", "50", "51", "52" ],
    14  :  [ "53", "54", "55", "56" ],
    15  :  [ "57", "58", "59", "60" ],
    16  :  [ "61", "62", "63", "64" ],   
    17  :  [ "65", "66", "67", "68" ],
    18  :  [ "69", "70", "71", "72" ],
    19  :  [ "73", "74", "75", "76" ],
    20  :  [ "77", "78", "79", "80" ],
    21  :  [ "81", "82", "83", "84" ],
    22  :  [ "85", "86", "87", "88" ],
    23  :  [ "89", "90", "91", "92" ],
    24  :  [ "93", "94", "95", "96" ],   
    25  :  [ "97", "98", "99", "00" ],   
}

/////////////////////////////////////////////////////////////////////////////////
// bet
// adjust which type to bet here
// bet 1 Animal, 2 Animal, 3 Animal, 4 Animal, 5 Animal, 2 Number, 3 Number, 4 Number
const betType = [ true, true, true, true, true, true, true, true ]

// bet settings
// [number of animal, and digit of number]
const betSettings = [ [ 1, 0 ], [ 2, 0 ], [ 3, 0 ], [ 4, 0 ], [ 5, 0 ], [ 0, 2 ], [ 0, 3 ], [ 0, 4 ] ]

// adjust number to bet on
const betOn = {
    // list of animal bet
    betOnAnimal : [
        [ allAnimal.animalOstrich ],
        [ allAnimal.animalOstrich, allAnimal.animalEagle ],
        [ allAnimal.animalOstrich, allAnimal.animalEagle, allAnimal.animalButterfly ],
        [ allAnimal.animalOstrich, allAnimal.animalEagle, allAnimal.animalButterfly, allAnimal.animalBear ],
        [ allAnimal.animalOstrich, allAnimal.animalEagle, allAnimal.animalButterfly, allAnimal.animalBear, allAnimal.animalAlligator ]
    ],

    // list of number bet
    betOnNumber : [
        "1234",
        "234",
        "34"
    ]
};

// fix the bet animal and number (true = yes, false = no)
const fixBet    = true;

// export
module.exports  = {
    totalSpin,
    betstake,
    maxNumber,
    maxAnimal,
    simResultFile,
    gameAvailableType,
    paytable,
    allAnimal,
    animalNumber,
    betType,
    betSettings,
    betOn,
    fixBet
}
