/////////////////////////////////////////////////////////////////////////////////
/* WholeGame.js
/////////////////////////////////////////////////////////////////////////////////
- this is the whole game flow
*/
/////////////////////////////////////////////////////////////////////////////////
// import
const fs                    = require('fs');
const Helper                = require("./Helper");
const Config                = require("./Config");

// initialise
const helper                = new Helper();

const betType               = Config.betType;
const betStake              = Config.betstake;
const totalSpin             = Config.totalSpin;
const betSettings           = Config.betSettings;
const simResultFile         = Config.simResultFile;

let betAnimal               = [];
let betNumber               = [];
let animalGenerated         = [];
let numberGenerated         = [];
let roundBet                = 0;
let totalPay                = 0;
let sse                     = 0;

let firstPositionAnimalWin  = false;
let anyPositionAnimalWin    = 0;
let firstPositionNumberWin  = false;
let anyPositionNumberWin    = false;
let animalNumberWin         = false;

let hit                     = 0;
let eachTypeHit             = Array.from({ length: 8 }, () => new Array(5).fill(0));
let eachTypePay             = Array.from({ length: 8 }, () => new Array(5).fill(0));

/////////////////////////////////////////////////////////////////////////////////
// Program start
const startTime = Date.now();

for(let spin = 0; spin < totalSpin; spin++){
    let betWin      = 0;
    let roundWin    = 0;
    roundBet        = 0;

    // generate random bet animal and number
    [betAnimal, betNumber]  = helper.genBetAnimalNumber();

    // generate random animal and number
    [animalGenerated, numberGenerated]  = helper.genAnimalNumber();

    // Animal Bet
    for(let i = 0; i < betAnimal.length; i++){
        let numOfAnimalBet = betAnimal[i].length;
    
        // check win type
        [firstPositionAnimalWin, anyPositionAnimalWin] = helper.checkAnimalWinType(animalGenerated, numOfAnimalBet, betAnimal[i]);
        
        // check payout
        [betWin, eachTypeHit, eachTypePay] = helper.checkAnimalPayout(firstPositionAnimalWin, anyPositionAnimalWin, numOfAnimalBet, eachTypeHit, eachTypePay);
        
        // accumulate record
        roundWin += betWin;
        roundBet += betStake;
    }

    // Number Bet
    for(let i = 0; i < betNumber.length; i++){
        let numOfNumberBet = betNumber[i].length;
    
        // check win type
        [firstPositionNumberWin, anyPositionNumberWin, animalNumberWin] = helper.checkNumberWinType(animalGenerated, numberGenerated, numOfNumberBet, betNumber[i]);
        
        // check payout
        [betWin, eachTypeHit, eachTypePay] = helper.checkNumberPayout(firstPositionNumberWin, anyPositionNumberWin, animalNumberWin, numOfNumberBet, eachTypeHit, eachTypePay);
        
        // accumulate record
        roundWin += betWin;
        roundBet += betStake;
    }

    // record hit 
    if(roundWin > 0){
        hit++;
    }

    totalPay    += roundWin;
    sse         += roundWin * roundWin / roundBet / roundBet;

    // print the progress
    if(spin % 10000000 == 0){
        // calculate volatility
        let mean    = totalPay / spin / roundBet;
        let std     = Math.sqrt((sse / spin) - (mean * mean));

        console.clear();
        console.log("Spin\t:\t" + spin + " / " + totalSpin);
        console.log("Volatility\t:\t" + std);
        console.log("Total RTP\t:\t" + (totalPay / spin / roundBet * 100) + "%");
        console.log("Type\t\t\t\t\tHit Count\tPayout");
        console.log("1 Animal (First Position)\t:\t" + eachTypeHit[0][0] + "\t\t" + eachTypePay[0][0]);
        console.log("1 Animal (Any Position)  \t:\t" + eachTypeHit[0][4] + "\t\t" + eachTypePay[0][4]);
        console.log("2 Animal (First 2 Position)\t:\t" + eachTypeHit[1][0] + "\t\t" + eachTypePay[1][0]);
        console.log("2 Animal (2 in Any Position)\t:\t" + eachTypeHit[1][3] + "\t\t" + eachTypePay[1][3]);
        console.log("2 Animal (Only 1 animal)\t:\t" + eachTypeHit[1][4] + "\t\t" + eachTypePay[1][4]);
        console.log("3 Animal (First 3 Position)\t:\t" + eachTypeHit[2][0] + "\t\t" + eachTypePay[2][0]);
        console.log("3 Animal (3 in Any Position)\t:\t" + eachTypeHit[2][2] + "\t\t" + eachTypePay[2][2]);
        console.log("3 Animal (Only 2 animal)\t:\t" + eachTypeHit[2][3] + "\t\t" + eachTypePay[2][3]);
        console.log("3 Animal (Only 1 animal)\t:\t" + eachTypeHit[2][4] + "\t\t" + eachTypePay[2][4]);
        console.log("4 Animal (First 4 Position)\t:\t" + eachTypeHit[3][0] + "\t\t" + eachTypePay[3][0]);
        console.log("4 Animal (4 in Any Position)\t:\t" + eachTypeHit[3][1] + "\t\t" + eachTypePay[3][1]);
        console.log("4 Animal (Only 3 animal)\t:\t" + eachTypeHit[3][2] + "\t\t" + eachTypePay[3][2]);
        console.log("4 Animal (Only 2 animal)\t:\t" + eachTypeHit[3][3] + "\t\t" + eachTypePay[3][3]);
        console.log("4 Animal (Only 1 animal)\t:\t" + eachTypeHit[3][4] + "\t\t" + eachTypePay[3][4]);
        console.log("5 Animal (All 5 Animal)  \t:\t" + eachTypeHit[4][0] + "\t\t" + eachTypePay[4][0]);
        console.log("5 Animal (Only 4 animal)\t:\t" + eachTypeHit[4][1] + "\t\t" + eachTypePay[4][1]);
        console.log("5 Animal (Only 3 animal)\t:\t" + eachTypeHit[4][2] + "\t\t" + eachTypePay[4][2]);
        console.log("5 Animal (Only 2 animal)\t:\t" + eachTypeHit[4][3] + "\t\t" + eachTypePay[4][3]);
        console.log("5 Animal (Only 1 animal)\t:\t" + eachTypeHit[4][4] + "\t\t" + eachTypePay[4][4]);
        console.log("Last 2 numbers (1st position)\t:\t" + eachTypeHit[5][0] + "\t\t" + eachTypePay[5][0]);
        console.log("Last 2 numbers (Any position)\t:\t" + eachTypeHit[5][1] + "\t\t" + eachTypePay[5][1]);
        console.log("Last 2 numbers (Only 1 animal)\t:\t" + eachTypeHit[5][2] + "\t\t" + eachTypePay[5][2]);
        console.log("Last 3 numbers (1st position)\t:\t" + eachTypeHit[6][0] + "\t\t" + eachTypePay[6][0]);
        console.log("Last 3 numbers (Any position)\t:\t" + eachTypeHit[6][1] + "\t\t" + eachTypePay[6][1]);
        console.log("Last 3 numbers (Only 1 animal)\t:\t" + eachTypeHit[6][2] + "\t\t" + eachTypePay[6][2]);
        console.log("4 numbers (1st position)\t:\t" + eachTypeHit[7][0] + "\t\t" + eachTypePay[7][0]);
        console.log("4 numbers (Any position)\t:\t" + eachTypeHit[7][1] + "\t\t" + eachTypePay[7][1]);
        console.log("4 numbers (Only 1 animal)\t:\t" + eachTypeHit[7][2] + "\t\t" + eachTypePay[7][2]);
    }
}

// Program end
const endTime   = Date.now();
let timeTaken   = (endTime - startTime) / 1000;
let mean        = totalPay / totalSpin / roundBet;
let std         = Math.sqrt((sse / totalSpin) - (mean * mean));

fs.appendFileSync(simResultFile, "\n\nTotal Spin\t:\t" + totalSpin + "\n");
fs.appendFileSync(simResultFile, "Volatility\t:\t" + std + "\n");
fs.appendFileSync(simResultFile, "Total RTP\t:\t" + (totalPay / totalSpin / roundBet * 100) + "%" + "\n");
fs.appendFileSync(simResultFile, "Type\t\t\t\t\tHit Count\tPayout" + "\n");
fs.appendFileSync(simResultFile, "1 Animal (First Position)\t:\t" + eachTypeHit[0][0] + "\t\t" + eachTypePay[0][0] + "\n");
fs.appendFileSync(simResultFile, "1 Animal (Any Position)  \t:\t" + eachTypeHit[0][4] + "\t\t" + eachTypePay[0][4] + "\n");
fs.appendFileSync(simResultFile, "2 Animal (First 2 Position)\t:\t" + eachTypeHit[1][0] + "\t\t" + eachTypePay[1][0] + "\n");
fs.appendFileSync(simResultFile, "2 Animal (2 in Any Position)\t:\t" + eachTypeHit[1][3] + "\t\t" + eachTypePay[1][3] + "\n");
fs.appendFileSync(simResultFile, "2 Animal (Only 1 animal)\t:\t" + eachTypeHit[1][4] + "\t\t" + eachTypePay[1][4] + "\n");
fs.appendFileSync(simResultFile, "3 Animal (First 3 Position)\t:\t" + eachTypeHit[2][0] + "\t\t" + eachTypePay[2][0] + "\n");
fs.appendFileSync(simResultFile, "3 Animal (3 in Any Position)\t:\t" + eachTypeHit[2][2] + "\t\t" + eachTypePay[2][2] + "\n");
fs.appendFileSync(simResultFile, "3 Animal (Only 2 animal)\t:\t" + eachTypeHit[2][3] + "\t\t" + eachTypePay[2][3] + "\n");
fs.appendFileSync(simResultFile, "3 Animal (Only 1 animal)\t:\t" + eachTypeHit[2][4] + "\t\t" + eachTypePay[2][4] + "\n");
fs.appendFileSync(simResultFile, "4 Animal (First 4 Position)\t:\t" + eachTypeHit[3][0] + "\t\t" + eachTypePay[3][0] + "\n");
fs.appendFileSync(simResultFile, "4 Animal (4 in Any Position)\t:\t" + eachTypeHit[3][1] + "\t\t" + eachTypePay[3][1] + "\n");
fs.appendFileSync(simResultFile, "4 Animal (Only 3 animal)\t:\t" + eachTypeHit[3][2] + "\t\t" + eachTypePay[3][2] + "\n");
fs.appendFileSync(simResultFile, "4 Animal (Only 2 animal)\t:\t" + eachTypeHit[3][3] + "\t\t" + eachTypePay[3][3] + "\n");
fs.appendFileSync(simResultFile, "4 Animal (Only 1 animal)\t:\t" + eachTypeHit[3][4] + "\t\t" + eachTypePay[3][4] + "\n");
fs.appendFileSync(simResultFile, "5 Animal (All 5 Animal)  \t:\t" + eachTypeHit[4][0] + "\t\t" + eachTypePay[4][0] + "\n");
fs.appendFileSync(simResultFile, "5 Animal (Only 4 animal)\t:\t" + eachTypeHit[4][1] + "\t\t" + eachTypePay[4][1] + "\n");
fs.appendFileSync(simResultFile, "5 Animal (Only 3 animal)\t:\t" + eachTypeHit[4][2] + "\t\t" + eachTypePay[4][2] + "\n");
fs.appendFileSync(simResultFile, "5 Animal (Only 2 animal)\t:\t" + eachTypeHit[4][3] + "\t\t" + eachTypePay[4][3] + "\n");
fs.appendFileSync(simResultFile, "5 Animal (Only 1 animal)\t:\t" + eachTypeHit[4][4] + "\t\t" + eachTypePay[4][4] + "\n");
fs.appendFileSync(simResultFile, "Last 2 numbers (1st position)\t:\t" + eachTypeHit[5][0] + "\t\t" + eachTypePay[5][0] + "\n");
fs.appendFileSync(simResultFile, "Last 2 numbers (Any position)\t:\t" + eachTypeHit[5][1] + "\t\t" + eachTypePay[5][1] + "\n");
fs.appendFileSync(simResultFile, "Last 2 numbers (Only 1 animal)\t:\t" + eachTypeHit[5][2] + "\t\t" + eachTypePay[5][2] + "\n");
fs.appendFileSync(simResultFile, "Last 3 numbers (1st position)\t:\t" + eachTypeHit[6][0] + "\t\t" + eachTypePay[6][0] + "\n");
fs.appendFileSync(simResultFile, "Last 3 numbers (Any position)\t:\t" + eachTypeHit[6][1] + "\t\t" + eachTypePay[6][1] + "\n");
fs.appendFileSync(simResultFile, "Last 3 numbers (Only 1 animal)\t:\t" + eachTypeHit[6][2] + "\t\t" + eachTypePay[6][2] + "\n");
fs.appendFileSync(simResultFile, "4 numbers (1st position)\t:\t" + eachTypeHit[7][0] + "\t\t" + eachTypePay[7][0] + "\n");
fs.appendFileSync(simResultFile, "4 numbers (Any position)\t:\t" + eachTypeHit[7][1] + "\t\t" + eachTypePay[7][1] + "\n");
fs.appendFileSync(simResultFile, "4 numbers (Only 1 animal)\t:\t" + eachTypeHit[7][2] + "\t\t" + eachTypePay[7][2] + "\n");

if (timeTaken > 60) {
    console.log(`Simulation Time Taken: ${timeTaken / 60} minutes`);
    fs.appendFileSync(simResultFile, `Simulation Time Taken: ${timeTaken / 60} minutes`);
}

else {
    console.log(`Simulation Time Taken: ${timeTaken} seconds`);
    fs.appendFileSync(simResultFile, `Simulation Time Taken: ${timeTaken} seconds`);
}