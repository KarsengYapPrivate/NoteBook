/////////////////////////////////////////////////////////////////////////////////
/* Helper.js
/////////////////////////////////////////////////////////////////////////////////
- this contain all the function for the game
*/
/////////////////////////////////////////////////////////////////////////////////
// import
const crypto = require('crypto');
const Config = require("./Config");

// initialise
const betOn             = Config.betOn;
const fixBet            = Config.fixBet;
const paytable          = Config.paytable;
const maxNumber         = Config.maxNumber;
const maxAnimal         = Config.maxAnimal;
const allAnimal         = Config.allAnimal;
const animalNumber      = Config.animalNumber;
const gameAvailableType = Config.gameAvailableType;
const totalAnimal       = Object.keys(allAnimal).length;

/////////////////////////////////////////////////////////////////////////////////
class Helper{
    // Generate server seed
    generateRandomString() {
        let length = this.randomBetweenInteger(20, 50);
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+[]{}|;:,.<>?';
        let result = '';
    
        for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        result += characters.charAt(randomIndex);
        }
    
        return result;
    }

    generateResult(seed) {
        const hash = crypto.createHmac('sha256', seed).digest('hex');
        const hmacInt = parseInt(hash.substring(0, 13), 16);
        const randomNumber = hmacInt / (Math.pow(2, 52) - 1);
        const [animalGenerated, numberGenerated] = this.genAnimalNumber(randomNumber);
      
        return [animalGenerated, numberGenerated];
    }    
    
    storeResult(serverSeedHashed, serverSeed, clientSeed, nounce, numberList) {
        let combineString = [serverSeedHashed, serverSeed, clientSeed, nounce].join('-');

        let pairs = numberList.join('').match(/../g); 
        let animalList = [pairs[1], pairs[3], pairs[5], pairs[7], pairs[9]];

        let printMsg = `
        ------------------------------------------------------------------------------------------- 
        Information display to player before game start:
        Served seed (hashed):   ${serverSeedHashed}
        ClientSeed:             ${clientSeed}
        Nounce:                 ${nounce}
        
        Information display to player after game end:
        String to verify:       ${combineString}
        Server seed (original): ${serverSeed}
        Animal Result:          ${animalList}
        Number Result:          ${numberList}`
    
        console.log(printMsg);
    }
  
    /////////////////////////////////////////////////////////////////////////////////
    // generate random bet animal and number
    genBetAnimalNumber(){
        let getRandomNumber = this.randomNumber(maxNumber); 
        let getSingleAnimal = [];
        let getSingleNumber = getRandomNumber.toString().padStart(4, '0');
        let betAnimal       = [];
        let betNumber       = [];

        for (let i = 0; i < maxAnimal; i++){
            getSingleAnimal.push(this.randomNumber(totalAnimal) + 1); 
        }

        betAnimal.push(getSingleAnimal);
        betNumber.push(getSingleNumber);

        // For fixed bet
        if(fixBet){
            betAnimal       = [...betOn.betOnAnimal];
            betNumber       = betOn.betOnNumber;
        }

        return [betAnimal, betNumber];
    }

    // generate random animal and number (result) 
    genAnimalNumber(randomNumber){
        let allrandomNumber = this.floatToDigitsStretched(randomNumber);
        let animalGenerated = [];
        let numberGenerated = [];

        for (let i = 0; i < maxAnimal; i++){
            let getNumber       = allrandomNumber.slice(0, 4); 
            allrandomNumber     = allrandomNumber.slice(4);
            let getAnimal       = this.getSymbolKey(getNumber.slice(-2));

            animalGenerated.push(getAnimal); 
            numberGenerated.push(getNumber);
        }  

        return [animalGenerated, numberGenerated];
    }

    // check for first position animal
    checkFirstAnimal(animalGenerated, numOfAnimalBet, betAnimal){
        // only for 5 animal bet
        if(numOfAnimalBet == 5){
            let tempAnimalBet   = [...betAnimal];
    
            for(let animalGen of animalGenerated){
                for(let i = 0; i < tempAnimalBet.length; i++){
                    if(animalGen == tempAnimalBet[i]){
                        tempAnimalBet.splice(i, 1);
                        break;
                    }
                }
            }

            if(tempAnimalBet.length == 0){
                return true;
            }

            return false;        
        }
        // other types of bet
        else{
            for(let i = 0; i < numOfAnimalBet; i++){
                if(betAnimal[i] != animalGenerated[i]){
                    return false;
                }
            }

            return true;
        }
    }

    // check animal appear on any position
    checkAnyAnimal(animalGenerated, betAnimal){
        let tempAnimalBet   = [...betAnimal];
        let animalHit       = 0;

        for(let animalGen of animalGenerated){
            for(let i = 0; i < tempAnimalBet.length; i++){
                if(animalGen == tempAnimalBet[i]){
                    tempAnimalBet.splice(i, 1);
                    animalHit++;
                    break;
                }
            }
        }
        
        return animalHit;
    }

    // check number matched with first position number
    checkFirstNumber(numberGenerated, numOfNumberBet, betNumber){
        let tempNumberBet       = betNumber.slice(-numOfNumberBet);
        let firstPositionNumber = numberGenerated[0].slice(-numOfNumberBet);

        if(firstPositionNumber == tempNumberBet){
            return true;
        }

        return false;
    }

    // check number matched with any position number
    checkAnyNumber(numberGenerated, numOfNumberBet, betNumber){
        let tempNumberBet       = betNumber.slice(-numOfNumberBet);

        for(let numberGen of numberGenerated){
            let tempNumberGen = numberGen.slice(-numOfNumberBet);

            if(tempNumberBet == tempNumberGen){
                return true;
            }
        }

        return false;
    }

    // check last 2 number matched with any animal's number
    checkAnimalNumber(animalGenerated, betNumber){
        // get last two digit of the number bet
        let tempNumberBet       = betNumber.slice(-2);

        for(let animal of animalGenerated){
            let thisAnimalNumber = animalNumber[animal];
            for(let number of thisAnimalNumber){
                if(number == tempNumberBet){
                    return true;
                }
            }
        }
        return false;
    }

    // check Animal Bet win type
    checkAnimalWinType(animalGenerated, numOfAnimalBet, betAnimal){
        let firstPositionAnimalWin          = false;
        let anyPositionAnimalWin            = 0;

        // Animal Bet
        // check for first position animal
        firstPositionAnimalWin              = this.checkFirstAnimal(animalGenerated, numOfAnimalBet, betAnimal);

        if(!firstPositionAnimalWin){
            // check for any position animal
            anyPositionAnimalWin            = this.checkAnyAnimal(animalGenerated, betAnimal);
        }

        return [firstPositionAnimalWin, anyPositionAnimalWin];
    }

    // check Number Bet win type
    checkNumberWinType(animalGenerated, numberGenerated, numOfNumberBet, betNumber){
        let firstPositionNumberWin          = false;
        let anyPositionNumberWin            = false;
        let animalNumberWin                 = false;

        // Number Bet
        // check for first position number
        firstPositionNumberWin              = this.checkFirstNumber(numberGenerated, numOfNumberBet, betNumber);

        if(!firstPositionNumberWin){
            // check for first position number
            anyPositionNumberWin            = this.checkAnyNumber(numberGenerated, numOfNumberBet, betNumber);
        }

        if(!firstPositionNumberWin && !anyPositionNumberWin){
            // check for animal's number
            animalNumberWin                 = this.checkAnimalNumber(animalGenerated, betNumber);
        }

        return [firstPositionNumberWin, anyPositionNumberWin, animalNumberWin];
    }

    // check animal payout
    checkAnimalPayout(firstPositionAnimalWin, anyPositionAnimalWin, numOfAnimalBet, eachTypeHit, eachTypePay){
        let payType         = gameAvailableType["animal" + numOfAnimalBet];
        let thisPaytable    = paytable[payType];
        let betWin          = 0;

        if(firstPositionAnimalWin){
            betWin = thisPaytable[0];
            eachTypeHit[payType][0]++;
            eachTypePay[payType][0] += betWin;
        }
        else {
            switch(anyPositionAnimalWin){
                case 4:     
                    betWin = thisPaytable[1];   
                    eachTypeHit[payType][1]++;
                    eachTypePay[payType][1] += betWin;
                    break;
                case 3:     
                    betWin = thisPaytable[2];   
                    eachTypeHit[payType][2]++;
                    eachTypePay[payType][2] += betWin;
                    break;
                case 2:     
                    betWin = thisPaytable[3];   
                    eachTypeHit[payType][3]++;
                    eachTypePay[payType][3] += betWin;
                    break;
                case 1:     
                    betWin = thisPaytable[4];   
                    eachTypeHit[payType][4]++;
                    eachTypePay[payType][4] += betWin;
                    break;
                default:    break;
            }
        }

        return [betWin, eachTypeHit, eachTypePay];
    }

    // check number payout
    checkNumberPayout(firstPositionNumberWin, anyPositionNumberWin, animalNumberWin, numOfNumberBet, eachTypeHit, eachTypePay){
        let payType         = gameAvailableType["number" + numOfNumberBet];
        let thisPaytable    = paytable[payType];
        let betWin          = 0;

        if(firstPositionNumberWin){
            betWin = thisPaytable[0];
            eachTypeHit[payType][0]++;
            eachTypePay[payType][0] += betWin;
        }
        else if(anyPositionNumberWin){
            betWin = thisPaytable[1];
            eachTypeHit[payType][1]++;
            eachTypePay[payType][1] += betWin;
        }
        else if(animalNumberWin){
            betWin = thisPaytable[2];
            eachTypeHit[payType][2]++;
            eachTypePay[payType][2] += betWin;
        }

        return [betWin, eachTypeHit, eachTypePay];
    }

    /////////////////////////////////////////////////////////////////////////////////
    // retrieve the symbol using the index
    getSymbolKey(value) {
        return Number(Object.keys(animalNumber).find(key => animalNumber[key].includes(value)));
    }

    // get a random number
    randomNumber(max){
        return Math.floor(Math.random() * max);
    }

    // get a random number from min to max
    randomBetweenInteger(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    // make float to larger digits number
    floatToDigitsStretched(randomFloat){
        let twentyDigits = '';
        let remaining = randomFloat;
      
        // Avoid 0.0 edge case (if needed, else remove this line)
        if (remaining === 0) remaining = 0.5; // Fallback
      
        // Split into 5 parts, generate 4 digits from each
        for (let i = 0; i < 5; i++) {
          // Stretch entropy: Multiply and take fractional part
          remaining *= 10000; // Scale to extract 4 digits
          const fourDigitChunk = Math.floor(remaining) % 10000;
          twentyDigits += fourDigitChunk.toString().padStart(4, '0');
          remaining %= 1; // Keep fractional part for next iteration
        }
      
        return twentyDigits;
    }      
}

// Export the module
module.exports = Helper;
