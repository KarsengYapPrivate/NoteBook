/////////////////////////////////////////////////////////////////////////////////
/* VerifyResult.js
/////////////////////////////////////////////////////////////////////////////////
- this is to verify the result of the game for the provably fair
*/
/////////////////////////////////////////////////////////////////////////////////
// import
const crypto    = require('crypto');
const Helper    = require("./Helper");
const Config    = require("./Config");

// initialise
const helper    = new Helper();

const allAnimal = Config.allAnimal;

/////////////////////////////////////////////////////////////////////////////////
// Separate information from the verify string
let verifyString        = "c42b10faf5c1e473587be78091e1878e795bcb5dda5ee5c17466f08a944c37dc-ih!u12Km6n!0YXkBnVi+o>+bjwXVb58?qa44S)b::]-IDWTODO-1";
let splitString         = verifyString.split('-');
let serverSeedHashed    = splitString[0].toString();
let serverSeed          = splitString[1].toString();
let clientSeed          = splitString[2].toString();
let nounce              = splitString[3].toString();
let numberList          = "6877,1832,4558,9383,6595";

let [animalGenerated, numberGenerated]  = generateResult(serverSeed, clientSeed, nounce);
let checkResult                         = verifyResult(numberGenerated, numberList);
let checkSeed                           = verifyServerSeedToServerSeedHashed(serverSeed, serverSeedHashed);
printResultSummary(checkResult, checkSeed, serverSeed, clientSeed, nounce, numberGenerated);

function generateResult(serverSeed, clientSeed, nounce) {

  const seed                                = [serverSeed, clientSeed, nounce].join('-');
  const hash                                = crypto.createHmac('sha256', seed).digest('hex');
  const hmacInt                             = parseInt(hash.substring(0, 13), 16);
  const randomNumber                        = hmacInt / (Math.pow(2, 52) - 1);
  const [animalGenerated, numberGenerated]  = helper.genAnimalNumber(randomNumber);

  return [animalGenerated, numberGenerated];
}


function verifyResult(numberGenerated, numberList) {
    let checkResult = false;

    numberGenerated = numberGenerated.join(',');

    if (numberGenerated == numberList) {
        checkResult = true;
    }

    return checkResult;
}

function printResultSummary(checkResult, checkSeed, serverSeed, clientSeed, nounce, numberGenerated) {
    let pairs = numberGenerated.join('').match(/../g); 
    let animalList = [pairs[1], pairs[3], pairs[5], pairs[7], pairs[9]];

    let printResultSummary = `
    =================================
         Summary of Verification
    =================================
    Result Verification status: ${checkResult}
    Seed Verification status: ${checkSeed}
    Hashed Seed: ${serverSeedHashed}
    Server Seed: ${serverSeed}
    Client Seed: ${clientSeed}
    Nounce: ${nounce}
    Animal Result: ${animalList}
    Number Result: ${numberGenerated}
    `;

   console.log(printResultSummary);
}

function verifyServerSeedToServerSeedHashed(serverSeed, serverSeedHashed) {

    let checkSeed = false;

    const hash = crypto.createHash('sha256').update(serverSeed).digest('hex');
    if (hash == serverSeedHashed) {
        checkSeed = true;
    }

    return checkSeed;
}
/////////////////////////////////////////////////////////////////////////////////